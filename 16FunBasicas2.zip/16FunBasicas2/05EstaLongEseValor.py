"""
Esta longitud, ese valor: escribe una función que acepte dos enteros como parámetros: 
tamaño y valor. La función debe crear y devolver una lista cuya longitud sea igual al 
tamaño dado, y cuyos valores sean todos el valor dado.
Ejemplo: length_and_value(4,7) debe devolver [7,7,7,7]
Ejemplo: length_and_value(6,2) debe devolver [2,2,2,2,2,2]
"""
from unittest import result


def longitudValor(tamano, valor):
    listaLongVal = []
    for i in range(0, tamano, 1):
        listaLongVal.append(valor)
    return listaLongVal

resultado = longitudValor(4, 7)
print(resultado)

resultado = longitudValor(6, 2)
print(resultado)