"""
3. Primero más longitud: crea una función que acepte una lista y devuelva la 
suma del primer valor de la lista, más la longitud de la lista.
Ejemplo: primero_mas_longitud([1,2,3,4,5]) 
debe devolver 6 (primer valor: 1 +length: 5)
"""

def primeroMasLongitud (listaNumeros):
    suma = listaNumeros[0] + len(listaNumeros)
    return suma
print(primeroMasLongitud([1, 2, 3, 4, 5]))