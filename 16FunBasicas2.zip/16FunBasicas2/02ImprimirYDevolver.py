"""
2.  Imprimir y devolver: crea una función que reciba una lista con dos números. Imprime el primer valor y 
devuelve el segundo.
Ejemplo: imprimir_y_devolver([1,2]) debe imprimir 1 y devolver 2
"""

def imprimirDevolver(listNumeros):
    print(listNumeros[0])
    return  listNumeros[1]

resultado = imprimirDevolver([1, 2])
print(resultado)
