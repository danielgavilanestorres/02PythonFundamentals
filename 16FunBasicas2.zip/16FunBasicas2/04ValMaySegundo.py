"""
Valores mayores que el segundo: escribe una función que acepte una lista 
y cree una nueva que contenga solo los valores de la lista original que sean 
mayores que su segundo valor. Imprime cuántos valores son y luego devuelve la 
lista nueva. Si la lista tiene menos de 2 elementos, has que la función devuelva 
False
Ejemplo: valores_mayores_que_el_segundo([5,2,3,2,1,4]) debe imprimir 3 y 
devolver [5,3,4]
Ejemplo: valores_mayores_que_el_segundo([3]) debe devolver False
"""

def valoresMayoresSegundo(listaNumeros):
    nuevaLista = []
    contadorMayor = 0
    if len(listaNumeros) <= 2:
        return False
    else:
        for i in range (0, len(listaNumeros), 2):
            if listaNumeros[i] > listaNumeros[i+1]:
                contadorMayor += 1
                nuevaLista.append(listaNumeros[i])
            else:
                contadorMayor += 1
                nuevaLista.append(listaNumeros[i+1])
    return nuevaLista, contadorMayor

print(valoresMayoresSegundo([1, 2]))

print(valoresMayoresSegundo([5, 2, 3, 2, 1, 4]))

print(valoresMayoresSegundo([4, 1, 3, 2, 2, 5]))